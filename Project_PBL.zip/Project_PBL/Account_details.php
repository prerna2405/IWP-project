<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
	}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
} 
$conn=dbconnect();
$sql="select * from user_details where username='$_SESSION[username]'";
$r=mysqli_query($conn,$sql);
$a=mysqli_fetch_array($r);
$conn->close();
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	#cname, #gender, #mob, #pin, #locality, #city, #state, #add, #email
	{
        padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 20rem;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
    }
    #one, #two
	{
		padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 5rem;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
    }
    #f
	{
		background-color: rgb(90,90,90);
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		padding: 15px;
		clear:both;
	}
    div.container
    {
	 width: 700px;
	 height: 610px;
	 margin:35px auto;
	 font-family: 'Raleway', sans-serif;
	}
	div.main{
	 width: 600px;
	 padding: 10px 50px 10px;
	 border: 6px solid gray;
	 border-radius: 10px;
	 font-family: Cambria;
	 float:left;
	}
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<br>
	<div class="container" align="center">
	  	<div class="main" align="center" style="font-size:110%; font-family:Cambria; color:rgb(15,30,50);">
		<form action="update.php" method="post" id="form" onsubmit="return enable()">
			<table>
				<tr><td><p align="center" style="font-size:200%; color:rgb(15,30,50);">Personal Information</p></td>
				<td><a id="one1" style="cursor:pointer;" onclick="Editgender()">Edit</a>
					<a id="1" style="cursor:pointer;" onclick="Cancelgender()"></a></td></tr>
				<tr><td><input type="text" value="" name="cname" id="cname"></td></tr>
			</table>
			<br>
			<table style="font-size:110%; font-family:Cambria; color:rgb(15,30,50);">
				<tr><td colspan="2">Your Gender</td></tr>
				<tr><td><input type="radio" value="male" id="male" name="gen"></td><td>Male</td></tr>
				<tr><td><input type="radio" value="female" id="female" name="gen"></td><td>Female</td></tr>
			</table>
			<br>
			<table>
				<tr><td><p align="center" style="font-size:200%; font-family:Cambria; color:rgb(15,30,50);">Email address</p></td>
				<td><a id="two2" style="cursor:pointer;" onclick="Edit('email','two2','2')">Edit</a>
					<a id="2" style="cursor:pointer;" onclick="Cancel('email','two2','2')"></a></td></tr>
				<tr><td><input type="text" name="email" id="email" value=""></p></td></tr>
			</table>
			<br>
			<a style="font-size:110%; font-family:Cambria; color:rgb(1,52,112); text-decoration: none;" id="redir" href="Change_pwd.php" onmouseover="document.getElementById('redir').style.color='white'" onmouseout="document.getElementById('redir').style.color='rgb(1,52,112)'">Change Password</a>
			<br>
			<br>
			<table>
				<tr><td><p align="center" style="font-size:200%; font-family:Cambria; color:rgb(15,30,50);">Mobile number</p></td>
				<td><a id="three3" style="cursor:pointer;" onclick="Edit('mob','three3','3')">Edit</a>
					<a id="3" style="cursor:pointer;" onclick="Cancel('mob','three3','3')"></a></td></tr>
				<tr><td><input type="text" value="" name="mob" id="mob"></td></tr>
			</table>
			<br>
			<table style="font-size:100%; font-family:Cambria; color:rgb(15,30,50);">
				<tr><td colspan="2"><p align="center" style="font-size:190%; font-family:Cambria; color:rgb(15,30,50);">Address</p></td>
				<td><a id="four4" style="cursor:pointer;" onclick="Editadd()">Edit</a>
					<a id="4" style="cursor:pointer;" onclick="Canceladd()"></a></td></tr>
				<tr><td>Pincode: </td><td><input type="text" name="pin" id="pin" value=""></td></tr>
	            <tr><td>Locality: </td><td><input type="text" name="locality" id="locality" value=""></td></tr>
	            <tr><td>Address and Street: </td><td><textarea value="" rows="3" col="5" name="add" id="add" style="font-family:cambria"></textarea></td></tr>
	            <tr><td>City/District/Town: </td><td><input type="text"  value="" name="city" id="city"></td></tr>
	            <tr><td>State: </td><td><input type="text" id="state" value="" name="states"></td><tr>
		    </table>
		    <br>
		    <table>
		    	<tr><td><input type="button" id="one" value="Cancel" onclick="window.open('BR.php','_self')"></td>
		    		<td><input type="submit" id="two" value="Update">
		    	</tr>
		    </table>
		</form>
		</div>
	</div>
	<br>
	<!-- The secton below contains the design for the footer -->
	<section align="center" style="width:100%; clear:both;">
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</section>
</body>
<script>
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("You need to login again");
	window.open('BR_Main.php','_self');
}
name="<?php echo $_SESSION['name']; ?>";
document.getElementById('cname').value=name;
document.getElementById('cname').disabled=true;
gender="<?php echo $a['gender']; ?>";
if(document.getElementById('male').value==gender)
	document.getElementById('male').checked=true;
else
	document.getElementById('female').checked=true;
document.getElementById('male').disabled=true;
document.getElementById('female').disabled=true;
email="<?php echo $a['email'];?>";
document.getElementById('email').value=email;
document.getElementById('email').disabled=true;
mob="<?php echo $a['mobile']; ?>";
document.getElementById('mob').value=mob;
document.getElementById('mob').disabled=true;
pin="<?php echo $a['pin']?>";
document.getElementById('pin').value=pin;
document.getElementById('pin').disabled=true;
locality="<?php echo $a['locality']; ?>";
document.getElementById('locality').value=locality;
document.getElementById('locality').disabled=true;
add="<?php echo $a['address']; ?>";
document.getElementById('add').value=add;
document.getElementById('add').disabled=true;
city="<?php echo $a['city']; ?>";
document.getElementById('city').value=city;
document.getElementById('city').disabled=true;
state="<?php echo $a['state']; ?>";
document.getElementById('state').value=state;
document.getElementById('state').disabled=true;
function Edit(x,y,z)
{
	document.getElementById(x).disabled=false;
	document.getElementById(y).innerHTML="";
	document.getElementById(z).innerHTML="Cancel"
}
function Cancel(x,y,z)
{
	document.getElementById(x).disabled=true;
	document.getElementById(y).innerHTML="Edit";
	document.getElementById(z).innerHTML="";
}
function Editadd()
{
	document.getElementById('pin').disabled=false;
	document.getElementById('locality').disabled=false;
	document.getElementById('add').disabled=false;
	document.getElementById('city').disabled=false;
	document.getElementById('state').disabled=false;
	document.getElementById("four4").innerHTML="";
	document.getElementById("4").innerHTML="Cancel";
}
function Canceladd()
{
	document.getElementById('pin').disabled=true;
	document.getElementById('locality').disabled=true;
	document.getElementById('add').disabled=true;
	document.getElementById('city').disabled=true;
	document.getElementById('state').disabled=true;
	document.getElementById("4").innerHTML="";
	document.getElementById("four4").innerHTML="Edit";
}
function Editgender()
{
	document.getElementById('cname').disabled=false;
	document.getElementById('male').disabled=false;
	document.getElementById('female').disabled=false;
	document.getElementById("one1").innerHTML="";
	document.getElementById("1").innerHTML="Cancel";
}
function Cancelgender()
{
	document.getElementById('cname').disabled=true;
	document.getElementById('male').disabled=true;
	document.getElementById('female').disabled=true;
	document.getElementById("1").innerHTML="";
	document.getElementById("one1").innerHTML="Edit";
}
function enable()
{
	document.getElementById('cname').disabled=false;
	document.getElementById('male').disabled=false;
	document.getElementById('female').disabled=false;
	document.getElementById('email').disabled=false;
	document.getElementById('mob').disabled=false;
	document.getElementById('pin').disabled=false;
	document.getElementById('locality').disabled=false;
	document.getElementById('add').disabled=false;
	document.getElementById('city').disabled=false;
	document.getElementById('state').disabled=false;
	return true;
}
</script>
</html>