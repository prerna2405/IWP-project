<?php
session_start();
$username="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['username']))
{
	$username=$_SESSION['username'];
}
$pid=$_POST['prid'];
$qty=$_POST['quantity'];
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
} 
$conn=dbconnect();
$price=$_POST['prod_price'];
$price*=$qty;
$conn->close();
$conn=dbconnect();
$sql="insert into cart (username, Product_id, Qty, Price) values ('$username','$pid','$qty','$price')";
$r=mysqli_query($conn,$sql);
if($r===TRUE)
	echo "<script>window.open('Products.php','_self')</script>";
else
	echo "<script>alert('Error in adding to cart'); window.open('Products.php','_self');</script>";
?>
