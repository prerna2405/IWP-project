<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
if(isset($_SESSION['username']))
{
	$uname=$_SESSION['username'];
}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
} 
$conn=dbconnect();
$sql="select * from order_info where order_id in (select order_id from order_status where status!='Delivered' and username='$uname');";
$res=mysqli_query($conn,$sql);
$n=mysqli_num_rows($res);
$i=0;
$pid=[];
$qty=[];
$price=[];
$pname=[];
$status=[];
if($n>0)
	while($a=mysqli_fetch_array($res))
	{
		$pid[$i]=$a['product_id'];
		$p=$pid[$i];
		$qty[$i]=$a['qty'];
		$o=$a['order_id'];
		$price[$i]=$a['price'];
		$s1="select status from order_status where order_id='$o'";
		$r1=mysqli_query($conn,$s1);
		$s="select Book_name from book_details where product_id='$p'";
		$r=mysqli_query($conn,$s);
		$pname[$i]=mysqli_fetch_array($r)['Book_name'];
		$status[$i]=mysqli_fetch_array($r1)['status'];
		$i++;
	}
$conn->close();
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	#tab
	{
		font-size: 110%;
		font-family: Cambria;
		color: white;
		border-spacing:15px;
		outline: 5px solid rgb(15,30,50);
	}
	#f
	{
		background-color: rgb(90,90,90)
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<div align="center">
		<p id="p" style="color:lightgrey; font-family:Cambria; font-size:200%;">Order Status</p>
		<form>
			<table id="tab" cellpadding="15">
			</table>
		</form>
	</div>
	<!-- The secton below contains the design for the footer -->
	<section align="center" style="width:100%; clear:both;">
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</section>
</body>
<script>
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("You need to login again");
	window.open('BR_Main.php','_self');
}
n=<?php echo $n; ?>;
if(n==0)
	document.getElementById('p').innerHTML='No ongoing orders';
else
{
	str="<tr><th>Book Name</th><th>Qty</th><th>Price</th><th>Status</th></tr>";
	pname=<?php echo '["' . implode('", "', $pname) . '"]' ?>;
	qty=<?php echo '["' . implode('", "', $qty) . '"]' ?>;
	price=<?php echo '["' . implode('", "', $price) . '"]' ?>;
	pid=<?php echo '["' . implode('", "', $pid) . '"]' ?>;
	stat=<?php echo '["' . implode('", "', $status) . '"]' ?>;
	for(i=0;i<n;i++)
	{
		str+="<tr><td>"+pname[i]+"</td>"+"<td>"+qty[i]+"</td>"+"<td>"+price[i]+"</td><td>"+stat[i]+"</td></tr>";
	}
	document.getElementById('tab').innerHTML=str;
}
</script>
</html>