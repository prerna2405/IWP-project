<?php
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
} 
//For categories
$i=0;
$gen=array();
$conn=dbconnect();
$sql="select distinct genre from book_details order by genre;";
$r= $conn->query($sql);
while($m=mysqli_fetch_array($r))
{
	$gen[$i++]=$m[0];
}
mysqli_free_result($r);
//For books in the default/chosen category
$conn=dbconnect();
$s="select Product_id, Book_Name, Genre from book_details order by Book_Name";
$m="All";
$pname=[];
$pid=[];
if(isset($_POST['hid']))
{
	$m=$_POST['hid'];
}
if ($m=="View All")
	$m="All";
$res=mysqli_query($conn,$s);
$j=0;
$count=0;
while($a=mysqli_fetch_array($res))
{
	if($m=="All" || $a['Genre']==$m)
	{
		$bname[$j]=$a['Book_Name'];
		$pid[$j++]=$a['Product_id'];
		$count++;
	}
}
$one=(int)($count/2);
mysqli_free_result($res);
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
$conn->close();
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	#cat
	{
		list-style-type: none;
		font-size: 110%;
		overflow:hidden;
		margin-right:5px;
	}
	#cat li
	{
		flex-grow: 1; 
		min-width: 150px;
		text-align:left;
		display:inline-block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:5px;
	}
	#cat li:hover
	{
		color: rgb(1,52,112);
		padding:5px;
	}
	#displist li
	{
		flex-grow: 1; 
		min-width: 150px;
		text-align:left;
		display:inline-block;
		text-decoration: none;
		color: rgb(15,30,50);
		padding:5px;
	}
	#displist li:hover
	{
		color: rgb(1,52,112);
		padding:5px;
	}
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<!-- The categories division -->	
	<div align="left" style="width:20%; height:150%; float:left;">
		<p style="font-size:150%; font-family:Cambria; color:rgb(24,24,24);" align="center"><b><i>Genres</i></b></p>
		<form id="catsel" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
			<input type="hidden" id="hid" name="hid" value="">
			<ul id="cat" onclick="redirect(event)" style="font-size:110%;"></ul>
		</form>
	</div>
	<!-- The product name display -->
	<div id="displist" align="left" style="width:80%; height:150%; float:right;">
		<b><p align="center" id="heading" style="font-size:170%; font-family:Cambria"></p></b>
		<div style="width:50%; float:left;">
			<ul id="one" onclick="gathermed(event);" style="cursor:pointer; font-size:110%; font-family:Cambria; list-style-type:none;"></ul>
		</div>
		<div style="width:50%; float:right;">
			<ul id="two" onclick="gathermed(event)" style="cursor:pointer; font-size:110%; font-family:Cambria; list-style-type:none;"></ul>
		</div>
	</div>
	<div>
		<form id="prod" action="Product_Details.php" method="post">
			<input type="hidden" name="book" id="book" value="">
		</form>
	</div>
</body>
<script>
var gen = <?php echo '["' . implode('", "', $gen) . '"]' ?>;
str="<li style='cursor:pointer;' id='View All'>View All</li>";
j=0;
for(i=0;i<gen.length;i++)
	str+="<li style='cursor:pointer;' id='"+gen[i]+"'>"+gen[i]+"</li>";
document.getElementById('cat').innerHTML=str;
function redirect(e)
{
	var element = e.target || e.srcElement;
    document.getElementById("hid").value=element.id;
    document.getElementById("catsel").submit();
}
document.getElementById("heading").innerHTML="<?php echo $m; ?>";
var one='<?php echo $one; ?>';
var c='<?php echo $count; ?>';
var plist=<?php echo '["' . implode('", "', $bname) . '"]' ?>;
var pid=<?php echo '["' . implode('", "', $pid) . '"]' ?>;
for(i=0;i<one;i++)
	document.getElementById('one').innerHTML+="<li id="+pid[i]+">"+plist[i]+"</li><br>";
for(j=one;j<c;j++)
	document.getElementById('two').innerHTML+="<li id="+pid[j]+">"+plist[j]+"</li><br>";
function gathermed(e)
{
	var element = e.target || e.srcElement;
    details=element.id;
    document.getElementById('book').value=details;
    document.getElementById("prod").submit();
}
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("You need to login again");
	window.open('BR_Main.php','_self');
}
</script>
</html>