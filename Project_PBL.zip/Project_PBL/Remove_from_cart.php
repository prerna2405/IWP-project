<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
if(isset($_SESSION['username']))
{
	$username=$_SESSION['username'];
}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
} 
$conn=dbconnect();
$sql="DELETE from cart where product_id='$_POST[productid]' and username='$username';";
$r=mysqli_query($conn,$sql);
if($r===TRUE)
{
	echo "<script>alert('Successfully removed from cart'); window.open('Cart.php','_self'); </script>";
}
else
{
	//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	echo "<script>alert('Error in removing from the cart. Try again later'); window.open('Cart.php','_self'); </script>";
}
$conn->close();
?>