<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
	}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
} 
$conn=dbconnect();
$sql="UPDATE user_details SET Name='$_POST[cname]',gender='$_POST[gen]',pin='$_POST[pin]',locality='$_POST[locality]',
address='$_POST[add]',city='$_POST[city]',state='$_POST[states]',email='$_POST[email]',mobile='$_POST[mob]' WHERE username='$_SESSION[username]'";
$r=mysqli_query($conn,$sql);
if($r===TRUE)
{
	$_SESSION['name']=$_POST['cname'];
	header('Location: BR.php');
}
?>