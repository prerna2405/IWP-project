<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
if(isset($_SESSION['username']))
{
	$uname=$_SESSION['username'];
}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
}
$pid=$_POST['prodid'];
$qty=(int)$_POST['qty'];
$price=(float)$_POST['price'];
$pin=(int)$_POST['pincode'];
$locality=$_POST['locality'];
$address=$_POST['address'];
$city=$_POST['ci'];
$state=$_POST['st'];
$pay=$_POST['pay'];
$conn=dbconnect();
$c="select * from order_info order by order_id desc;";
$c2="select * from transaction_details order by trans_id desc;";
$num=0;
$n=0;
$r=mysqli_query($conn,$c); 
$r2=mysqli_query($conn,$c2); 
$a=mysqli_fetch_array($r);
$a2=mysqli_fetch_array($r2);
$num=$a['order_id']+1;
$n=$a2['trans_id']+1;
$s="INSERT INTO order_info(order_id,product_id, username, qty, price, pin, locality, address, city, state, payment) VALUES ('$num','$pid','$uname','$qty','$price','$pin','$locality','$address','$city','$state','$pay')";
$res=mysqli_query($conn,$s); 
if($res===TRUE)
{
	$t="INSERT into transaction_details(trans_id, order_id, username, card_num) VALUES ('$n','$num','$uname','$_POST[cnum]')";
	$res2=mysqli_query($conn,$t);
	if($res2===TRUE)
	{
		$del="delete from cart where product_id=$pid";
		$res2=mysqli_query($conn,$del);
		$ins="insert into order_status values ('$num','Order Placed');";
		$res3=mysqli_query($conn,$ins);
		$sto="update product_stock set stock_num=stock_num-$qty where product_id=$pid";
		$res4=mysqli_query($conn,$sto);
		$redirect=1;
	}
	else
		echo "<script>alert('Error in placing the order'); window.open('Cart.php','_self');</script>";
}
else
	echo "<script>alert('Error in placing the order'); window.open('Cart.php','_self');</script>";
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	/* The Modal (background) */
	.Transaction 
	{
	    display: none; /* Hidden by default */
	    position: fixed; /* Stay in place */
	    z-index: 1; /* Sit on top */
	    padding-top: 100px; /* Location of the box */
	    left: 0;
	    top: 0;
	    width: 100%; /* Full width */
	    height: 100%; /* Full height */
	    overflow: auto; /* Enable scroll if needed */
	    background-color: rgb(0,0,0); /* Fallback color */
	    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
	}
	/* Modal Content */
	.Trans-processing
	{
	    background-color: #fefefe;
	    margin: auto;
	    padding: 20px;
	    border: 1px solid #888;
	    width: 80%;
	    height:300px;
	}
	</style>
</head>
<body>
<!-- The Modal -->
<div id="TransactionP" class="Transaction">
  <!-- Modal content -->
  <div class="Trans-processing">
    <p id="p" align="center" style="font-size:150%; font-family:Cambria">Transaction Processing.... Please wait</p>
  </div>
</div>
<script>
r=<?php echo $redirect; ?>;
if(r==1)
	redirect();
// Get the modal
function redirect()
{
	var modal = document.getElementById('TransactionP');
	modal.style.display="block";
	setTimeout(f,7000); 
	function g()
	{
		window.open('BR.php','_self');
	}
	function f()
	{
		document.getElementById('p').innerHTML="Transaction Successful";
		setTimeout(g,3000); 
	}
}
</script>
</body>
</html>