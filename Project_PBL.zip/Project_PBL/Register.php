<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
} 
$i=0;
$check="select * from user_details;";
$r=$conn->query($check);
$uname=[];
$email=[];
$mobile=[];
while($m=mysqli_fetch_array($r))
	{
		$uname[$i]=$m['Username'];
		$email[$i]=$m['email'];
		$mobile[$i++]=$m['mobile'];
	}
if($_POST)
{
	$un=$_POST['username1'];
	$em=$_POST['email'];
	$mob=$_POST['mob'];
	$pwd=str_rot13($_POST["pwd1"]);
	$sql = "INSERT INTO user_details (Name, Username, pwd, dob, gender, pin, locality, address, city, state, email, mobile) 
	VALUES 
	('$_POST[name]', '$_POST[username1]','$pwd', '$_POST[dob]', '$_POST[gender]', '$_POST[pin]','$_POST[locality]', '$_POST[add]', '$_POST[city]', '$_POST[states]', '$_POST[email]', '$_POST[mob]')";
	if ($conn->query($sql)=== TRUE) // Session can be applied here instead
	{
	    echo "<script>alert('Registered successfully. Now try to log in'); window.open('BR_Main.php','_self');</script>";
	}
	else
	{
		echo"<script> alert('Registration unsuccessful. Try again'); window.open('Register.php','_self');</script>";
	}
	$conn->close();
}
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
	}
	#f
	{
		background-color: rgb(90,90,90);
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		padding: 15px;
		clear:both;
	}
	#Name, #pwd1, #pwd2, #Mob, #Email, #dob, #pin,
	#locality, #add, #state, #city, #Username1
    {
        padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 20rem;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
    }
	#registration
    {
        text-decoration: none;
        color: rgb(200,200,200);
        display: block;
        font-size: 110%;
    }
	#reg, #Register
    {
        padding:10px;
        margin:0.5rem;
        background-color: rgb(200,200,200);
        font-size: 110%;
        vertical-align: middle;
    }
    div.container{
	 width: 700px;
	 height: 610px;
	 margin:35px auto;
	 font-family: 'Raleway', sans-serif;
	}
	div.main{
	 width: 600px;
	 padding: 10px 50px 10px;
	 border: 6px solid gray;
	 border-radius: 10px;
	 font-family: Cambria;
	 float:left;
	}
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
    <!-- The section below contains the design for the search box, search button and the Login/Register portal -->
	<div>
		<header id="h" style="background-color:rgb(24,24,24)">
			<div align="center">
				<div>
					<img src="icon.png" id="ima">
				</div>
		</header>
	</div>
	<br>
	<h1 style="color:lightgrey;" align="center">Registration Form</h1>
	<div class="container" align="center">
	  	<div class="main">
	  		<p id='alerting' style="color:lightgrey;font-size: 110%;"></p>
	  		<p id='alerting1' style="color:lightgrey;font-size: 110%;"></p>
			<form name="Register" id="registration" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" onsubmit="return validation()">
		        <table>
		            <tr><td>Full Name: </td><td><input type="text" name="name" id="Name"></td></tr>
		            <tr><td>Date of Birth: </td><td><input type="date" name="dob" id="dob"></td></tr>
		            <tr><td rowspan="2">Gender: </td>
		            <td><input type="radio" name="gender" id="male" value="male">Male</td></tr>
		            <tr><td><input type="radio" name="gender" id="female" value="female">Female</td></tr>
		            <tr><td>Username: </td><td><input type="text" name="username1" id="Username1" onchange="checkun(this.value)"></td></tr>
		           	<tr><td>Password: </td><td><input type="password" name="pwd1" id="pwd1"></td></tr>
		            <tr><td>Re-Enter Password: </td><td><input type="password" name="pwd2" id="pwd2" onkeyup="checkpwd(this.value); return false;"></td></tr>
		            <tr><td>Pincode: </td><td><input type="text" name="pin" id="pin"></td></tr>
		            <tr><td>Locality: </td><td><input type="text" name="locality" id="locality"></td></tr>
		            <tr><td>Address and Street: </td><td><textarea rows="3" col="5" name="add" id="add" style="font-family:cambria"></textarea></td></tr>
		            <tr><td>City/District/Town: </td><td><input type="text"  name="city" id="city"></td></tr>
		            <tr><td>State: </td><td><input type="text" id="state" name="states"></td><tr>
		            <tr><td>Mobile Number: </td><td><input type="text" name="mob" id="Mob" onchange="checkmob(this.value)"></td></tr>
		            <tr><td>Email: </td><td><input type="email" name="email" id="Email" onchange="checkemail(this.value)"></td></tr>
		        </table>
		        <input type="submit" value="Register" id="reg">
		    </form>
		</div>
	</div>
	<!-- The secton below contains the design for the footer -->
	<div>
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</div>
</body>
<script>
//Function to check the validity of password
function checkpwd(str)
{
    //Store the password field objects into variables ...
    var pass1 = document.getElementById('pwd1');
    var pass2 = document.getElementById('pwd2');
    //Set the colors we will be using ...
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
    //Compare the values in the password field 
    //and the confirmation field  
    if(pass1.value === str)
    {
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password 
        var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;  
		if(pass1.value.match(decimal)) 
        	pass2.style.backgroundColor = goodColor;
        else
        document.getElementById("alerting1").innerHTML="Make a password such that there is atleast"+ 
        " one uppercase letter, one number, one special character and length is greater than 8";
    }
    else
    {
        //The passwords do not match.
        //Set the color to the bad color and
        //notify the user.
        pass2.style.backgroundColor = badColor;
    }
}
//Function to check the validity of all fields
function validation()
{
	if(document.getElementById('Name').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter your name";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(!document.getElementById('dob').value)
	{
		document.getElementById("alerting").innerHTML="Please enter your date of birth";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(!(document.getElementById('male').checked || document.getElementById('female').checked))
	{
		document.getElementById("alerting").innerHTML="Please pick a gender";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('Username1').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter a usename";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('pwd1').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter a password";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('pin').value=="" || (document.getElementById('pin').value).match(/[^0-9]/g) || document.getElementById('pin').value.length!=6)
	{
		document.getElementById("alerting").innerHTML="Please enter a valid pin number";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('locality').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter your locality";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('add').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter your address";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('city').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter your City/Town/District";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('state').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter your state";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('mob').value=="" || (document.getElementById('mob').value).match(/[^0-9]/g) || document.getElementById('mob').value.length!=10)
	{
		document.getElementById("alerting").innerHTML="Please enter a valid mobile number";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
	if(document.getElementById('email').value=="")
	{
		document.getElementById("alerting").innerHTML="Please enter your email address";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		return false;
	}
}
function checkun(name)
{
	var username = <?php echo '["' . implode('", "', $uname) . '"]' ?>;
	if(username.indexOf(name)!=-1)
	{
		document.getElementById("alerting").innerHTML="Username Exists. Try another one";
		document.body.scrollTop = 0;
    	document.documentElement.scrollTop = 0;
		document.getElementById('Username1').value="";
	}
}
function checkemail(em)
{
	var email = <?php echo '["' . implode('", "', $email) . '"]' ?>;
	if(email.indexOf(em)!=-1)
	{
		alert("Email exists. That means you have an account. Log in instead.");
		window.open('BR_Main.php','_self');
	}
}
function checkmob(mob)
{
	var mobno = <?php echo '["' . implode('", "', $mobile) . '"]' ?>;
	if(mobno.indexOf(mob)!=-1)
	{
		alert("Mobile number exists. That means you have an account. Log in instead.");
		window.open('BR_Main.php','_self');
	}
}
</script>
</html>