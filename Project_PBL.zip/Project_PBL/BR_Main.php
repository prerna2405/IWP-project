<?php
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['username']))
	header("Location: BR.php");
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	nav ul
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	nav ul li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	nav ul li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	nav ul li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#f
	{
		background-color: rgb(90,90,90);
		text-align: center;
		color:lightgrey;
		flex-grow:1;
	}
	#prev, #next
	{
		cursor: pointer;
		position: absolute;
		top: 60%;
		width: auto;
		color:black;
		font-weight: bold;
		border-radius: 0 3px 3px 0;
		font-size: 50px;
		padding:16px;
		transition: 0.5s ease;
	}
	#next
	{
		right: 0;
		border-radius: 3px 0 0 3px;
	}
	#prev
	{
		left:0;
	}
	#prev:hover, #next:hover
	{
		color:white;
		background-color: black;
	}
	#image
	{
		width:100%;
	}
	/* Login box modal box*/
	#imamodal
    {
        width:130px;
        height:100px;
        padding-left: 9em;
        padding-right: 9em;
    }
	.modal, .modal2
    {
        display: none; /* Hidden by default */
        position: absolute; /* Stay in place */
        z-index: 1; /* Sit on top */
        padding-top: 100px; /* Location of the box */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        background-color: rgb(0,0,0); /* Fallback color */
        background-color: rgba(0,0,0,0.5); /* Black w/ opacity */
    }
	.modal-content 
    {
        background-color: rgb(90,90,90);
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }
	.modal-head
    {
        background-color: rgb(24,24,24);
        padding:5px;
    }
	#Username, #pwd, #Name, #pwd1, #pwd2, #Mob, #Email, #dob, #pin,
	#locality, #add, #state, #city, #Username1
    {
        padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 20rem;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
    }
	#log, #registration
    {
        text-decoration: none;
        color: rgb(200,200,200);
        text-align:center;
        display: block;
        font-size: 110%;
    }
	#Login, #reg, #Register
    {
        padding:10px;
        margin:0.5rem;
        background-color: rgb(200,200,200);
        font-size: 110%;
        vertical-align: middle;
    }
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
	<div>
		<header id="h" style="background-color:rgb(24,24,24)">
			<div align="right" style="color:white">
				<a href="" id="uname"></a>
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form>
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima">
					</div>
					<div align="center">
						<input type="text" id="S" placeholder="Search book..." align="center">
						<input type="Button" id="Search" Value="Search" Onclick="">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul>
					<li><a style="cursor: pointer;" onclick="login()">Login/Register</a></li>
					<li><a style="cursor: pointer;" onclick="login()">About Us</a></li>
					<li><a style="cursor: pointer;" onclick="login()">FAQ</a></li>
					<li><a style="cursor: pointer;" onclick="login()">Products</a></li>
					<li><a href="BR_Main.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<br>
	<!-- The section below contains the design for a slideshow -->
	<div>
		<a onclick="prev()" id="prev">&#10094</a>
		<img id="image" src="">
		<a onclick="next()" id="next">&#10095</a>
	</div>
	<br>
	<div>
		<center>
		<img src="classic.jpeg" id="im" width=330 height=165>
		<img src="fiction.jpeg" id="im" width=330 height=165>
		<img src="non-fiction.jpeg" id-"im" width=330 height=165>
		<img src="mystery.jpeg" id="im" width=330 height=165>
		</center>
	</div>
	<br>
	<br>
	<br>
	<!--Modal box for login with an alternative to register if there is no account -->
	<div id="Modal" class="modal">
        <div class="modal-content">
            <form name="Log" id="log" action="login.php" method="post" onsubmit="return check()">
            <div class="modal-head">
                <img src="icon.png" id="imamodal">
            </div>
            <center>
                <br><br>
                <table style="color:lightgrey; font-size:110%">
                    <tr><td>Username: </td><td><input type="text" name="username" id="Username"></td></tr>
                    <tr><td>Password: </td><td><input type="password" name="pwd" id="pwd"></td></tr>
                </table>
                <input type="Submit" value="Log in" id="Login">
            </form>
            <hr width="500" border="4">
            OR
            <form name="register">
                <input type="button" value="Register" name="reg" id="reg" onclick="redirect()">
            </form>
            </center>
        </div>
    </div> 
	<!-- The secton below contains the design for the footer -->
	<div>
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</div>
<script language="javascript">
// Automatic Slideshow - change image every 5 seconds
var imslider=["1 one.png","2 two.png","3 three.png","4 four.png","5 five.png"];
num=0;
var img=document.getElementById("image");
img.src=imslider[num];
setInterval(next,5000);
function next()
{
	var img=document.getElementById("image");
	num++;
	if(num>=imslider.length)
		num=0;
	img.src=imslider[num];
}
function prev()
{
	var img=document.getElementById("image");
	num--
	if(num<0)
		num=4;
	img.src=imslider[num];
}
//Function for the modal box
setTimeout(login,7000);        
var modal = document.getElementById('Modal');
var regis=document.getElementById('Modal2');
function login() {
    modal.style.display = "block";
}
function redirect()
{
    modal.style.display="none";
    window.open("Register.php","_self");
}
function check()
{
	un=document.getElementById("Username").value;
	pwd=document.getElementById("pwd").value;
	if(un=="")
	{
		alert("Enter username");
		return false;
	}
	else if(pwd=="")
	{
		alert("Enter password");
		return false;
	}
}
</script>
</body>
</html>