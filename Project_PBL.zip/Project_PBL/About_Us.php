<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	#f
	{
		background-color: rgb(90,90,90)
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<br>
	<div>
		<table>
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px;"></td>
				<td style="font-size:200%; font-family:Cambria; color:rgb(200,200,200);">About Us</td>
			</tr>
		</table>
		<p align="justify" style="padding-left:1em; font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
		For bibliophiles, a book is their universe from where they withdraw inspiration, motivation, empathise or become one with the characters of the story and experience the rare sort of an euphoria that even materialistic things cannot bring. Like good, old and loyal friends, books come to rescue each time you are put into trouble to offer the gems of wisdom locked in words. They are are also like time-machine that takes us to meet the legends of the past and their captivating history. Maybe that's why, there's no other better mentor than books; no bigger inspiration than books. Now, with online books store, buying books have become really easy with multitude of genres present at one place.
		</p><p align="justify" style="padding-left:1em; font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
		Curious minds and the quester spirit, finds home in the books. Technology might have replaced, ample of things; but don't worry, none of them have been able to replace the books. Just a mid-way of bringing convenience of technology and beauty of reading books, on one single stage, called the 'Online Bookstore'. On BR, there is a wide collection of online books of Indian as well as foreign authors. Buy books online from our online shopping portal, as you get convenience of varied payment options &copy; easy delivery of the books at your doorstep.
		</p>
	</div>
	<div align="left" style="width:100%; height:100%; float:right;">
		<div style="width:40%; float:left; padding-left:5em;">
			<table align="center">
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px; padding-left:20px;"></td>
			</tr>
			<tr>
				<td style="font-size:150%; font-family:Cambria; color:rgb(200,200,200);">Convenience</td>
			</tr>
		</table>
		<p align="justify" style=" font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
		There are a number of good stores from where you can buy books online. Though, the pricing of the books varies from store to store. So depending on how much you're saving and if your book's availability, you might want to get a book from somewhere other than your preferred store. We help you do all this in just one click! 
		</p><p align="justify" style=" font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
		With so many titles, it is vital to give customers an easy way to find precisely the books they are looking for. Our search engine enables customers to locate books by title, author, or keyword in a few seconds at most. Customers with a general idea of what they want can use our Browse pages to sift through hundreds of categories to find exactly the right book.
		</p>
		</div>
		<div style="width:40%; float:right;  padding-right:5em;"> 
		<table align="center">
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px; padding-left:20px;"></td>
			</tr>
			<tr>
				<td style="font-size:150%; font-family:Cambria; color:rgb(200,200,200);">One Time Shop</td>
			</tr>
		</table>
		<p align="justify" style="font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
			At BR, we not only provide you with a wide range of books listed under various categories, we also offer a 
			wide choice of products books.
		</p>
		<table align="center">
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px; padding-right: 25px;"></td>
			</tr>
			<tr>
				<td style="font-size:150%; font-family:Cambria; color:rgb(200,200,200); padding-left:20px;">Trust</td>
			</tr>
		</table>
		<p align="justify" style="font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
			BR continues a legacy of success in the Online bookstore industry. We are committed to provide safe, 
			reliable and affordable books as well as a customer service philosophy that is worthy of our valued customers’ loyalty. 
			We offer a superior online shopping experience, which includes ease of navigation and absolute transactional security.
		</p>
		</div>
	</div>
	<!-- The secton below contains the design for the footer -->
	<section align="center" style="width:100%; clear:both;">
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</section>
</body>
<script>
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("Session got lost. Log in again");
	window.open('BR_Main.php','_self');
}
</script>
</html>