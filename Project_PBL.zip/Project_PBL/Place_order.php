<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
if(isset($_SESSION['username']))
{
	$uname=$_SESSION['username'];
}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
}
$pid=$_POST['prodid'];
$bname=$_POST['bname'];
$qty=$_POST['qty'];
$price=$_POST['price'];
$conn=dbconnect();
$sql="select pin, locality, address, city, state from user_details where Username='$uname'";
$res=mysqli_query($conn,$sql);
$a=mysqli_fetch_array($res);
$pin=$a['pin'];
$locality=$a['locality'];
$address=$a['address'];
$city=$a['city'];
$state=$a['state'];

?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	.cout
	{
	    background-color: rgb(15,30,50);
	    color: white;
	    padding: 16px;
	    font-size: 16px;
	    border: none;
	    cursor: pointer;
	}
	#tab
	{
		font-size: 110%;
		font-family: Cambria;
		color: white;
		border-spacing:15px;
		outline: 5px solid rgb(15,30,50);
	}
	#tab2
	{
		font-size: 110%;
		font-family: Cambria;
		color: black;
		border-spacing:15px;
		padding-top: 10px;
		padding-bottom: 20px;
	}
	#p
	{
		font-size: 110%;
		font-family: Cambria;
		color: lightgrey;
	}
	#p2
	{
		font-size: 110%;
		font-family: Cambria;
		color: rgb(15,30,50);
		cursor: pointer;
	}
	#p2:hover
	{
		font-size: 110%;
		font-family: Cambria;
		color: rgb(1,52,112);
	}
	/* The Modal (background) */
	.modal 
	{
	    display: none; /* Hidden by default */
	    position: fixed; /* Stay in place */
	    z-index: 1; /* Sit on top */
	    padding-top: 100px; /* Location of the box */
	    left: 0;
	    top: 0;
	    width: 100%; /* Full width */
	    height: 100%; /* Full height */
	    overflow: auto; /* Enable scroll if needed */
	    background-color: rgb(0,0,0); /* Fallback color */
	    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
	}
	/* Modal Content */
	.modal-content 
	{
	    background-color: #fefefe;
	    margin: auto;
	    padding: 20px;
	    border: 1px solid #888;
	    width: 50%;
	}
	/* The Close Button */
	.close 
	{
	    color: #aaaaaa;
	    float: right;
	    font-size: 28px;
	    font-weight: bold;
	}
	.close:hover,
	.close:focus 
	{
	    color: #000;
	    text-decoration: none;
	    cursor: pointer;
	}
	#f
	{
		background-color: rgb(90,90,90)
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<br><br>
	<!-- The section confirms and processes the order placing -->
	<div>
		<table id="tab" cellpadding="15">
		</table>
	</div>
	<div>
		<p id="p"></p>
		<a id="p2" onclick="openmodal()">Change address</a>
		<p id="p">Payment Mode: </p>
		<form id="p">
			<input type="radio" name="r" id="COD" value="COD"> Cash on delivery<br>
			<input type="radio" name="r" id="Card" value="Card"> Credit/Debit Card
		</form>
		<br>
		<form>
			<input type="button" class="cout" value="Place Order" onclick="sub()">
		</form>
	</div>
	<br><br>
	<!-- The Modal -->
	<div id="Modal" class="modal">
		<!-- Modal content -->
		<div class="modal-content">
	    	<span class="close">&times;</span>
	    	<img src="Icon.png">
	    	<p style="font-size:150%; font-family:Cambria; color:black;" align="center">Change Address</p>
	    	<div align="center">
	    		<form>
	    			<table id="tab2">
	    				<tr><td>Pincode</td>
	    					<td><input type='text' id="pin"></td></tr>
	    				<tr><td>Locality</td>
	    					<td><input type='text' id="loc"></td></tr>
	    				<tr><td><tr><td>Address and Street: </td>
	    					<td><textarea rows="5" col="10" name="add" id="add" style="font-family:cambria"></textarea></td></tr>
	    				<tr><td>City/District/Town: </td>
	    					<td><input type="text"  name="city" id="city"></td></tr>
		            	<tr><td>State: </td>
		            		<td><input type="text" id="state" name="states"></td><tr>
		            	<tr><td colspan="2" align="center"><input type="button" value="Change Address" class="cout" onclick="change()"></td></tr>
		            </table>
		        </form>
		    </div>
	  	</div>
	</div>
	<form id="f1" name="f1" action="order.php" method="post">
		<input type="hidden" value="" id="pincode" name="pincode">
		<input type="hidden" value="" id="locality" name="locality">
		<input type="hidden" value="" id="address" name="address">
		<input type="hidden" value="" id="ci" name="ci">
		<input type="hidden" value="" id="st" name="st">
		<input type="hidden" value="" id="prodid" name="prodid">
		<input type="hidden" value="" id="qty" name="qty">
		<input type="hidden" value="" id="price" name="price">
		<input type="hidden" value="" id="pay" name="pay">
	</form>
	<form id="f2" name="f2" action="Online_payment.php" method="post">
		<input type="hidden" value="" id="pincode" name="pincode">
		<input type="hidden" value="" id="locality" name="locality">
		<input type="hidden" value="" id="address" name="address">
		<input type="hidden" value="" id="ci" name="ci">
		<input type="hidden" value="" id="st" name="st">
		<input type="hidden" value="" id="prodid" name="prodid">
		<input type="hidden" value="" id="qty" name="qty">
		<input type="hidden" value="" id="price" name="price">
		<input type="hidden" value="" id="pay" name="pay">
	</form>
	<!-- The secton below contains the design for the footer -->
	<section align="center" style="width:100%; clear:both;">
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</section>
</body>
<script>
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("You need to login again");
	window.open('BR_Main.php','_self');
}
bname="<?php echo $bname; ?>";
pid="<?php echo $pid; ?>";
qty=<?php echo $qty; ?>;
price=<?php echo $price; ?>;
str="<tr><th>Book Name</th><th>Qty</th><th>Price</th>";
str+="<tr><td>"+bname+"</td>"+"<td>"+qty+"</td>"+"<td>"+price+"</td></tr>";
document.getElementById('tab').innerHTML=str;
pincode='<?php echo $pin; ?>';
locality='<?php echo $locality; ?>';
city='<?php echo $city; ?>';
state='<?php echo $state; ?>';
address='<?php echo $address; ?>';
s="Delivery Address: "
document.getElementById('p').innerHTML=s+address;
// Get the modal
var modal = document.getElementById('Modal');
// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
// When the user clicks the button, open the modal 
function openmodal() 
{
    modal.style.display = "block";
}
// When the user clicks on <span> (x), close the modal
span.onclick = function() 
{
    modal.style.display = "none";
}
function change()
{
	modal.style.display = "none";
	pincode=document.getElementById('pin').value;
	locality=document.getElementById('loc').value;
	address=document.getElementById('add').value;
	city=document.getElementById('city').value;
	state=document.getElementById('state').value;
	document.getElementById('p').innerHTML=s+address;
} 
function sub()
{
	r=document.getElementsByName('r');
	document.f1.pincode.value=pincode;
	document.f2.pincode.value=pincode;
	document.f1.locality.value=locality;
	document.f2.locality.value=locality;
	document.f1.address.value=address;
	document.f2.address.value=address;
	document.f1.ci.value=city;
	document.f2.ci.value=city;
	document.f1.st.value=state;
	document.f2.st.value=state;
	document.f1.prodid.value=pid;
	document.f2.prodid.value=pid;
	document.f1.qty.value=qty;
	document.f2.qty.value=qty;
	document.f1.price.value=price;
	document.f2.price.value=price;
	if(r[0].checked)
	{
		document.f1.pay.value='COD';
		document.getElementById("f1").submit();
	}
	else if (r[1].checked)
	{
		document.f2.pay.value='Card';
		document.getElementById("f2").submit();
	}
	else
		alert('Pick a mode of payment');
}
</script>
</html>