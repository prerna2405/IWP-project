<?php 
session_start();
if (isset($_SESSION['name']) && isset($_SESSION['username']))
{
	$_SESSION['name']="";
	$_SESSION['username']="";
	session_unset();
	session_destroy();
}
?>
<script>
function disableBack()
{
	window.history.forward();
}
disableBack();
window.onload=disableBack();
window.onpageshow = function(event)
{
	if (event.persisted)
		disableBack();
}
window.onunload = function() 
{
	void(0);
}
window.open('BR_Main.php','_self');
</script>