<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
		#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	#faqlist li:hover
	{
		color: rgb(1,52,112);
		cursor: pointer;
	}
	#f
	{
		background-color: rgb(90,90,90)
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<br>
	<div>
		<table>
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px;"></td>
				<td style="font-size:200%; font-family:Cambria; color:rgb(200,200,200);">FAQ - Frequently Asked Questions</td>
			</tr>
		</table>
		<p style="padding-left:5em; font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
		At BR, we are dedicated to providing a seamless shopping experience to all our customers. To help guide you through your online shopping with us, we have compiled a list of frequently asked questions and provided answers below. If you don’t find your question, you are always welcome to contact us and we will get back to you as soon as possible by emailing us at br_queries@gmail.com.
		</p>
	</div>
	<div id="Gen">
		<table>
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px;"></td>
				<td style="font-size:200%; font-family:Cambria; color:rgb(200,200,200);">General Questions</td>
			</tr>
		</table>
		<ul id="faqlist" style="padding-left:5em; font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
			<li onclick="dispinfo(1)">What are your hours of operation?</li>
			<p id="1" style="display:none; color:rgb(138,0,0);">Our website is open 24 hours a day, 7 days a week. Call Centre support is available from Monday to Saturday, 09:00 am to 09:00 pm IST.</p>
			<li onclick="dispinfo(2)">Is it safe to use my credit/debit card at BR?</li>
			<p id="2" style="display:none; color:rgb(138,0,0);">Yes. BR uses third-party payment processing services to process all credit/debit card payment transactions. These payment intermediaries are PCI-compliant, which is the most stringent level of certification standard that ensures all cardholders’ data is stored, processed and transmitted securely by using the industry standard encryption technology.</p>
		</ul>
	</div>
	<div id="Ord">
		<table>
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px;"></td>
				<td style="font-size:200%; font-family:Cambria; color:rgb(200,200,200);">Ordering Questions</td>
			</tr>
		</table>
		<ul id="faqlist" style="padding-left:5em; font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
			<li onclick="dispinfo(3)">What information do you need from me to process my order as fast as possible?</li>
			<p id="3" style="display:none; color:rgb(138,0,0);">In order to process your order quickly, we need the following details from you:<br>Your billing/shipping informationYour payment details.</p>
			<li onclick="dispinfo(4)">Are there any other hidden charges?</li>
			<p id="4" style="display:none; color:rgb(138,0,0);">No. There are no hidden charges in any of our products.</p>
			<li onclick="dispinfo(5)">What forms of payment does BR accept for online orders?</li>
			<p id="5" style="display:none; color:rgb(138,0,0);">BR accepts the following forms of payment:<br>
			- Credit/debit card<br>
			- Net banking<br>
			- Cash on Delivery (COD)<br>
			Note: Credit/debit card and net banking payments are processed via our online payment service partners.</p>
			<li onclick="dispinfo(6)">Are all your product prices quoted in Indian Rupees?</li>
			<p id="6" style="display:none; color:rgb(138,0,0);">Yes, all product prices quoted in our website are in Indian Rupees.</p>
			<li onclick="dispinfo(7)">How is my order packaged?</li>
			<p id="7" style="display:none; color:rgb(138,0,0);">BR takes greatest possible care in packaging your order. Untouched by human hands, your order will be packaged in factory-sealed blister-packs.</p>
		</ul>
	</div>
	<div id="Del">
		<table>
			<tr>
				<td><img type="type/png" src="icon.png" style="width: 95px; height: 65px;"></td>
				<td style="font-size:200%; font-family:Cambria; color:rgb(200,200,200);">Delivery Questions</td>
			</tr>
		</table>
		<ul id="faqlist" style="padding-left:5em; font-size:120%; font-family:Cambria; color: rgb(15,30,50);">
			<li onclick="dispinfo(8)">How long will it take to deliver my order?</li>
			<p id="8" style="display:none; color:rgb(138,0,0);">Delivery times may vary depending on the delivery location as well as the type of product you order.</p>
			<li onclick="dispinfo(9)">What is Cash on Delivery (COD)?</li>
			<p id="9" style="display:none; color:rgb(138,0,0);">Cash on Delivery (COD) is a payment method by which you can pay for your ordered item(s) in cash when the courier company delivers the item(s) to you at your delivery address.<br>
			Don't own a credit/debit card? Or don't wish to pay online? Rather than making any advance online payment, BR' COD option gives you the flexibility to pay the complete order amount on delivery.</p>
			<li onclick="dispinfo(10)">How do I cancel my order?</li>
			<p id="10" style="display:none; color:rgb(138,0,0);">In case your order has already been ordered, charged or delivered, we cannot cancel it.</p>
			<li onclick="dispinfo(11)">Is it possible to cancel my order after it has been charged?</li>
			<p id="11" style="display:none; color:rgb(138,0,0);">No, you cannot cancel your order once your payment has been processed.</p>
			<li onclick="dispinfo(12)">Can I change my delivery address after I have placed my order?</li>
			<p id="12" style="display:none; color:rgb(138,0,0);">If your order has not been shipped yet, then we can deliver to a different address as per your request. </p>
			<li onclick="dispinfo(13)">How will my order be delivered?</li>
			<p id="13" style="display:none; color:rgb(138,0,0);">Your order will be delivered by EMS or Courier, depending on your pincode.</p>
		</ul>
	</div>
	<!-- The secton below contains the design for the footer -->
	<section align="center" style="width:100%; clear:both;">
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</section>
</body>
<script>
function dispinfo(i)
{
	for(j=1;j<=13;j++)
		if(j!=i)
			document.getElementById(j).style.display="none";	
	document.getElementById(i).style.display="block";
}
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("Session got lost. Log in again");
	window.open('BR_Main.php','_self');
}
</script>
</html>