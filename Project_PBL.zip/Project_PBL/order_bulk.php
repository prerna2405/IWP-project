<?php
session_start();
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['username']))
{
	$uname=$_SESSION['username'];
}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
}
$pin=(int)$_POST['pincode'];
$locality=$_POST['locality'];
$address=$_POST['address'];
$city=$_POST['ci'];
$state=$_POST['st'];
$pay=$_POST['pay'];
$conn=dbconnect();
$y="select * from cart where username='$uname'";
$yy=mysqli_query($conn,$y);
$q=0;
while($z=mysqli_fetch_array($yy))
{
	$c="select * from order_info order by order_id desc;";
	$num=0;
	$r=mysqli_query($conn,$c); 
	$a=mysqli_fetch_array($r);
	$num=$a['order_id']+1;
	$pid=$z['Product_id'];
	$qty=(int)$z['Qty'];
	$price=(float)$z['Price'];
	$s="INSERT INTO order_info(order_id,product_id, username, qty, price, pin, locality, address, city, state, payment) VALUES ('$num','$pid','$uname','$qty','$price','$pin','$locality','$address','$city','$state','$pay')";
	$res=mysqli_query($conn,$s); 
	if($res===TRUE)
	{
		$del="delete from cart where product_id=$pid";
		$res2=mysqli_query($conn,$del);
		$ins="insert into order_status values ('$num','Order Placed');";
		$res3=mysqli_query($conn,$ins);
		$sto="update product_stock set stock_num=stock_num-1 where product_id=$pid";
		$res4=mysqli_query($conn,$sto);
	}
	$q=1;	
}
if($q==1)
	echo "<script>alert('Order Placed'); window.open('BR.php','_self')</script>";
else
	echo "<script>alert('Error in placing the order'); window.open('Cart.php','_self');</script>";
$conn->close();
?>