<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
if(isset($_SESSION['username']))
{
	$uname=$_SESSION['username'];
}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
}
$pin=$_POST['pincode'];
$locality=$_POST['locality'];
$address=$_POST['address'];
$city=$_POST['ci'];
$state=$_POST['st'];
$pay=$_POST['pay'];
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	#f
	{
		background-color: rgb(90,90,90)
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
	div.container
    {
	 width: 700px;
	 height: 610px;
	 margin:35px auto;
	 font-family: 'Raleway', sans-serif;
	}
	div.main{
	 width: 600px;
	 padding: 10px 50px 10px;
	 border: 6px solid gray;
	 border-radius: 10px;
	 font-family: Cambria;
	 float:left;
	}
	#cardname, #cnum
	{
        padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 20rem;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
    }
    #cvv
    {
    	padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 1em;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
        width:64px;
    }
    #expdate
    {
    	padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 1em;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
        width:89px;
    }
    #po
	{
		padding:5px;
        background-color: rgb(200,200,200);
        flex-grow: 1; 
        min-width: 5rem;
        margin:0.5rem;
        font-size: 110%;
        vertical-align: middle;
    }
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<!--Input the card details -->
	<p style="color:lightgrey;font-size: 200%; font:family:Cambria;"align="center">Card Details</p>
	<div class="container" align="center">
	  	<div class="main" align="center">
	  		<p id='alerting' style="color:lightgrey;font-size: 110%;"></p>
	  		<form action="Transactionb_processing.php" method="post" id="onpay" onsubmit="return validation()">
	  			<table style="font-size:110%; font-family:Cambria; color:rgb(15,30,50);">
	  				<tr><td>Card Holder Name: </td><td><input type="text" id="cardname"></td></tr>
	  				<tr><td>Card Number: </td><td><input type="text" name="cnum" id="cnum"></td></tr>
	  				<tr><td>CVV: </td><td><input type="text" id="cvv">
	  					<img src="CreditCards.png" id="cc" style="width:215px; height:50px;"></td></tr>
	  				<tr><td>Expiry Date: </td><td><input type="text" id="expdate">Format: mm/yyyy</td></tr>
	  			</table>
	  			<input type="hidden" value="" id="pincode" name="pincode">
				<input type="hidden" value="" id="locality" name="locality">
				<input type="hidden" value="" id="address" name="address">
				<input type="hidden" value="" id="ci" name="ci">
				<input type="hidden" value="" id="st" name="st">
				<input type="hidden" value="" id="pay" name="pay">
	  			<input type="Submit" value="Place Order" id="po" name="f1" style="font-size:110%; font-family:Cambria; color:rgb(15,30,50);">
	  		</form>
	  	</div>
	</div>
	<!-- The secton below contains the design for the footer -->
	<section align="center" style="width:100%; clear:both;">
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</section>
</body>
<script>
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("You need to login again");
	window.open('BR_Main.php','_self');
}
function validation()
{
	d=document.getElementById('expdate').value;
	m=d[0]+d[1];
	m=parseInt(m);
	yr=d[3]+d[4]+d[5]+d[6];
	yr=parseInt(yr);
	y=new Date();
	yy=y.getFullYear();
	yy=parseInt(yy);
	mm=y.getMonth();
	mm=parseInt(mm)+1;
	if(document.getElementById('cnum').value=="" || document.getElementById('cvv').value=="" || document.getElementById('expdate').value=="" || document.getElementById('cardname').value=="")
	{
		document.getElementById('alerting').innerHTML='Please fill in all the fields';
		return false;
	}
	if(d.length!=7)
	{
		document.getElementById('alerting').innerHTML='Fill in the expiry date of the card in the right format';
		return false;
	}
	if(d[2]!='/')
	{
		document.getElementById('alerting').innerHTML='Fill in the expiry date of the card in the right format';
		return false;
	}
	if(yr<yy)
	{
		document.getElementById('alerting').innerHTML='Your card has expired';
		return false;
	}
	if(yr==yy)
		if(m<mm)
			{
				document.getElementById('alerting').innerHTML='Your card has expired';
				return false;
			}
		else if(m>12)
			{
				document.getElementById('alerting').innerHTML='Fill in the expiry date of the card in the right format';
				return false;
			}
	if(document.getElementById('cvv').value.length!=3)
	{
		document.getElementById('alerting').innerHTML='This card cvv number is not valid';
		return false;
	}
	if(document.getElementById('cnum').value.length!=16)
	{
		document.getElementById('alerting').innerHTML='This card is not valid';
		return false;
	}
	return true;
}
pincode='<?php echo $pin; ?>';
locality='<?php echo $locality; ?>';
city='<?php echo $city; ?>';
state='<?php echo $state; ?>';
address='<?php echo $address; ?>';
document.getElementById('pincode').value=pincode;
document.getElementById('locality').value=locality;
document.getElementById('address').value=address;
document.getElementById('ci').value=city;
document.getElementById('st').value=state;
document.getElementById('pay').value='Card';
</script>
</html>