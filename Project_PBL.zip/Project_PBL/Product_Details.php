<?php
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
}
//To get the details of the book
if(isset($_POST['book']))
{
	$conn=dbconnect();
	$s="select * from book_details order by Product_id";
	$res=mysqli_query($conn,$s);
	$stat="Available";
	$dis=0;
	$snum=0;
	while($a=mysqli_fetch_array($res))
	{
		$prodid=$a['Product_Id'];
		if($prodid==$_POST['book'])
		{
			$bname=$a['Book_name'];
			$category=$a['Genre'];
			$author=$a['Author'];
			$publisher=$a['Publisher'];
			$price=(int)$a['Price'];
			$pr1=$price;
			$t="select * from product_stock where product_id='$prodid'";
			$r=mysqli_query($conn,$t);
			$b=mysqli_fetch_array($r);
			if($b['discount']!=0)
			{
				$dis=$b['discount'];
				$price-=(float)(($dis/100)*$price);
			}
			$snum=$b['stock_num'];
			if($b['stock_num']==0)
				$stat="Out of Stock";
			break;
		}
	}
}
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: M4A_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
		echo "<script>name='$name';</script>";
	}
$conn->close();
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	#navi
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	#navi li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	#navi li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	#navi li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#uname 
	{
	    cursor: pointer;
	}
	.dropdown1
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown1:hover #accdet 
	{
	    display: block;
	}
	#cat
	{
		list-style-type: none;
		font-size: 110%;
		overflow:hidden;
		margin-right:5px;
	}
	#cat li
	{
		flex-grow: 1; 
		min-width: 150px;
		text-align:left;
		display:inline-block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:5px;
	}
	#cat li:hover
	{
		color: rgb(1,52,112);
		padding:5px;
	}
	div.container{
		width: 700px;
		height: 500px;
		margin:35px auto;
		font-family: 'Raleway', sans-serif;
	}
	div.main{
		width: 600px;
		padding: 10px 50px 10px;
		border: 6px solid gray;
		border-radius: 10px;
		font-family: Cambria;
		float:left;
	}
	/*The drop down qty navigation */
	.dropbtn 
	{
	    background-color: rgb(15,30,50);
	    color: white;
	    padding: 16px;
	    font-size: 16px;
	    border: none;
	    cursor: pointer;
	}
	.dropbtn:hover, .dropbtn:focus {
	    background-color: rgb(1,52,112);
	}
	.dropdown {
	    position: relative;
	    display: inline-block;
	}
	.dropdown-content 
	{
    display: none;
    position: absolute;
    background-color: rgb(1,52,112);
    min-width: 160px;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
	}
	.dropdown-content a 
	{
	    color: white;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	.dropdown a:hover {background-color:rgb(15,30,50); }
	.show {display:block;}
	#f
	{
		background-color: rgb(90,90,90)
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
	#scart
	{
		margin-top: 0;	
	}
	/*Add to cart button */
	#addcart
	{
	    background-color: rgb(15,30,50);
	    color: white;
	    padding: 16px;
	    font-size: 16px;
	    border: none;
	    cursor: pointer;
	}
	#f
	{
		background-color: rgb(90,90,90)
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
		<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown1" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<br><br><br>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<div>
			<nav>
				<ul id="navi">
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</div>
		</header>
	</div>
	<br><br>
	<div class="container">
		<div class="main">
			<div id="details" style="font-family:Cambria; font-size:110%; color:rgb(15,30,50);">
				<p id='heading' align="center" style="font-size:250%; color:lightgrey; margin:0;"></p>
				<i><p id="author" align="center" style="margin:0;"></p></i>
				<br><br>
				<div style="float:left; width:20%; height:50%;">
					<img src="Book.png" style="width:270px; height:250px;" border="3">
				</div>
				<br>
				<div style="float:right; width:50%; font-size:110%; color:rgb(15,30,50);">
					Genre: <p id="cat" style="color:rgb(0,0,153); margin:0"></p>
					<br>
					Published By: <b><p id="pname" style="color:rgb(0,0,153); margin:0"></p></b>
					<br>
					Price: <p id="price" style="color:rgb(0,0,153); margin:0"></p>
					<br>
					Status: <p id="status" style="color:rgb(138,0,0); margin:0"></p>
					<p id="discount" style="display:none; margin-bottom:0px">Discount:</p>
					<p id="discount1" style='color:rgb(138,0,0); margin:0;'></p>
					<br>
					<!-- The quantity of medicines you want to buy -->
					<div class="dropdown" style="float:left; width:90px;">
					  	<button id="Qty" onclick="toggle()" class="dropbtn">Qty: 1</button>
						<div id="Dropdown" class="dropdown-content">
					    	<a onclick="change(2)" style="cursor:pointer;">2</a>
					    	<a onclick="change(3)" style="cursor:pointer;">3</a>
					    	<a onclick="change(4)" style="cursor:pointer;">4</a>
					  	</div>
					</div>
					<div style="float:right; width:10px; padding-right:100px;">
						<form action="Add_To_Cart.php" method="post">
						  	<input type="hidden" value="1" id="ch" name="quantity">
						  	<input type="hidden" value="" id="prodid" name="prid">
						  	<input type="hidden" value="" id="prod_price" name="prod_price">
						  	<input type="submit" id="addcart" value="Add to Cart">
					  	</form>
					</div>
					<br><br>
					<br><br>
				</div>
			</div>
		</div>
	</div>
	<br><br>
	<br><br>
	<br><br>
	<!-- The secton below contains the design for the footer -->
	<section align="center" style="width:100%; clear:both;">
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</section>
</body>
<script>
pid="<?php echo $prodid; ?>";
bname="<?php echo $bname; ?>";
category="<?php echo $category; ?>";
pname="<?php echo $publisher; ?>";
author="<?php echo $author; ?>";
price="Rs. "+"<?php echo $price; ?>"+"/-";
pr=<?php echo $pr1; ?>;
product_price=<?php echo $price; ?>;
stats="<?php echo $stat; ?>";
discount=<?php echo $dis; ?>;
pri=price;
snum=<?php echo $snum; ?>;
if(stats=="Out of Stock")
{
	document.getElementById('addcart').disabled=true;
	document.getElementById('addcart').style.cursor="not-allowed";
}
if(discount!=0)
{
	document.getElementById('discount').style.display="block";
	document.getElementById('discount1').innerHTML= discount+"%";
	pri="<s style='color:rgb(138,0,0)'>Rs." +pr +"</s> "+price;
}
document.getElementById('heading').innerHTML=bname;
document.getElementById('author').innerHTML=author;
document.getElementById('cat').innerHTML=category;
document.getElementById('pname').innerHTML=pname;
document.getElementById('price').innerHTML=pri;
document.getElementById('status').innerHTML=stats;
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function toggle() 
{
    document.getElementById("Dropdown").classList.toggle("show");
}
// Close the dropdown if the user clicks outside of it
window.onclick = function(event) 
{
  if (!event.target.matches('.dropbtn')) 
  {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
function change(z)
{
	if(snum-z<0)
	{
		alert('Pick a lesser quantity, there is a shortage of stock');
		z=1;
	}
	else
		document.getElementById('Qty').innerHTML="Qty: "+z;
	document.getElementById('ch').value=z;
}
document.getElementById('prodid').value=pid;
document.getElementById('prod_price').value=parseInt(product_price);
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("You need to login again");
	window.open('BR_Main.php','_self');
}
</script>
</html>