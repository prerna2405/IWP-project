<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
	}
?>
<!Doctype html>
<html>
<head>
	<title>Book Rush</title>
	<link rel="icon" type="type/png" href="icon.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	#h
	{
		background-color: rgb(90,90,90);
		padding:10px;
	}
	#ima
	{
		width:130px;
		height:100px;
		vertical-align: middle;
		padding-left: 1.8em;
		padding-right: 9.0em;
	}
	#S
	{
		padding:10px;
		background-color: rgb(200,200,200);
		flex-grow: 1; 
		min-width: 35rem;
		margin:0.5rem;
		font-size: 110%;
		vertical-align: middle;
	}
	#Search
	{
		padding:10px;
		margin:0.5rem;
		background-color: rgb(200,200,200);
		font-size: 110%;
		vertical-align: middle;
	}
	span nav ul
	{
		background-color: rgb(24,24,24);
		list-style-type: none;
		overflow:hidden;
		font-size: 110%
	}
	span nav ul li
	{
		float:right;
		flex-grow: 1; 
		min-width: 150px;
		text-align:center;
	}
	span nav ul li a
	{
		display:block;
		text-decoration: none;
		color: rgb(200,200,200);
		padding:10px;
		font-size: 110%;
	}
	span nav ul li a:hover
	{
		background-color: lightgrey;
		color:black;
		padding:10px;
	}
	#f
	{
		background-color: rgb(90,90,90);
		text-align: center;
		color:lightgrey;
		flex-grow:1;
		float:bottom;
	}
	#prev, #next
	{
		cursor: pointer;
		position: absolute;
		top: 60%;
		width: auto;
		color:black;
		font-weight: bold;
		border-radius: 0 3px 3px 0;
		font-size: 50px;
		padding:16px;
		transition: 0.5s ease;
	}
	#next
	{
		right: 0;
		border-radius: 3px 0 0 3px;
	}
	#prev
	{
		left:0;
	}
	#prev:hover, #next:hover
	{
		color:white;
		background-color: black;
	}
	#image
	{
		width: 100%;
		height: 338px;
	}
		#uname 
	{
	    cursor: pointer;
	}
	.dropdown
	{
	    position: relative;
	    display: inline-block;
	}
	#Acc
	{
		float:right; 
		display:block;
	}
	#Acc div a
	{
		float:left;
		padding-top: 8px;
		padding-left: 35px;
		color:lightgrey;
		text-decoration: none;
		font-size: 100%;
		font-family: Cambria;
	}
	#scart
	{
		margin-top: 0;	
	}
	#accdet
	{
	    display: none;
	    position: absolute;
	    min-width: 160px;
	    top:25px;
	    z-index: 1;
	    height: 25px;
	    width: 25px;
	    padding-top: 15‒;
	    margin-top: 20px;
	}
	#accdet a 
	{
	    color: lightgrey;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}
	#accdet a:hover {color:white;}
	.dropdown:hover #accdet 
	{
	    display: block;
	}
	</style>
</head>
<body style="background-color:rgb(90,90,90);">
	<!-- The section below contains the design for the search box, search button and the Login/Register portal -->
	<div>
		<header id="h" style="background-color:rgb(24,24,24);">
			<div align="right" id="Acc">
				<div class="dropdown" style="float:left; width:100px;">
				    <a id="uname"></a>
				    <br>
						<div id="accdet" style="cursor:pointer">
							<a href="Account_details.php">Account</a>
							<a href="Order_Status.php">Order Status</a>
							<a href="Order_History.php">Order History</a>
						</div>
				</div>
				<div style="float:right">
					<a id="cart" href="Cart.php">Shopping Cart</a>
					<a href="Cart.php" style="padding-top: 0px; padding-left: 0px;"><img id="scart" src="cart.png" style="cursor: pointer;"></a>	
				</div>	
			</div>
			<div style="font-family:Cambria; color:rgb(90,90,90);">
				<form action="Search.php" method="post">
					<div style="font-family:Cambria; font-size:200%; color:rgb(90,90,90);">
						<img src="icon.png" id="ima" style="float:left">
					</div>
					<div align="center" style="clear:both">
						<input type="text" id="S" name="S" placeholder="Search book..." align="center">
						<input type="submit" id="Search" Value="Search">
					</div>
				</form>
			</div>
		<!-- The section below contains the design for the navigation button -->
		<span>
			<nav>
				<ul>
					<li><a href="Logout.php">Logout</a></li>
					<li><a href="About_Us.php">About Us</a></li>
					<li><a href="FAQ.php">FAQ</a></li>
					<li><a href="Products.php">Products</a></li>
					<li><a href="BR.php">Home</a></li>
				</ul>
			</nav>
		</span>
		</header>
	</div>
	<br>
	<!-- The section below contains the design for a slideshow -->
	<div>
		<a onclick="prev()" id="prev">&#10094</a>
		<img id="image" src="">
		<a onclick="next()" id="next">&#10095</a>
	</div>
	<br>
	<div>
		<center>
		<img src="classic.jpeg" id="im" width="330" height="165">
		<img src="fiction.jpeg" id="im" width="330" height="165">
		<img src="non-fiction.jpeg" id-"im" width="330" height="165">
		<img src="mystery.jpeg" id="im" width="330" height="165">
		</center>
	</div>
	<br>
	<br>
	<br>
	<!-- The secton below contains the design for the footer -->
	<div>
		<footer id="f" text-align=center>Copyright &copy; A&T Designs</footer>
	</div>
<script language="javascript">
// Automatic Slideshow - change image every 5 seconds
var imslider=["1 one.png","2 two.png","3 three.png","4 four.png","5 five.png"];
num=0;
var img=document.getElementById("image");
img.src=imslider[num];
setInterval(next,5000);
function next()
{
	var img=document.getElementById("image");
	num++;
	if(num>=imslider.length)
		num=0;
	img.src=imslider[num];
}
function prev()
{
	var img=document.getElementById("image");
	num--
	if(num<0)
		num=4;
	img.src=imslider[num];
}
name="";
name="<?php echo $name; ?>";
document.getElementById('uname').innerHTML=name;
if(name=="")
{
	alert("You need to login again");
	window.open('BR_Main.php','_self');
}
</script>
</body>
</html>