<?php
session_start();
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['username']))
{
	$uname=$_SESSION['username'];
}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
}
$pid=$_POST['prodid'];
$qty=(int)$_POST['qty'];
$price=(float)$_POST['price'];
$pin=(int)$_POST['pincode'];
$locality=$_POST['locality'];
$address=$_POST['address'];
$city=$_POST['ci'];
$state=$_POST['st'];
$pay=$_POST['pay'];
$conn=dbconnect();
$c="select * from order_info order by order_id desc;";
$num=0;
$r=mysqli_query($conn,$c); 
$a=mysqli_fetch_array($r);
$num=$a['order_id']+1;
$s="INSERT INTO order_info(order_id,product_id, username, qty, price, pin, locality, address, city, state, payment) VALUES ('$num','$pid','$uname','$qty','$price','$pin','$locality','$address','$city','$state','$pay')";
$res=mysqli_query($conn,$s); 
if($res===TRUE)
{
	$del="delete from cart where product_id=$pid";
	$res2=mysqli_query($conn,$del);
	$ins="insert into order_status values ('$num','Order Placed');";
	$res3=mysqli_query($conn,$ins);
	$sto="update product_stock set stock_num=stock_num-1 where product_id=$pid";
	$res4=mysqli_query($conn,$sto);
	echo "<script>alert('Order Placed'); window.open('BR.php','_self')</script>";
}
else
	echo "<script>alert('Error in placing the order'); window.open('Cart.php','_self');</script>";
$conn->close();
?>