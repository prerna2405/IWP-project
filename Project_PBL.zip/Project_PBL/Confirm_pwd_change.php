<?php
session_start();
$name="";
if($_SESSION['name']==null)
	header("Location: BR_Main.php");
if(isset($_SESSION['name']))
	{
		$name=$_SESSION['name'];
	}
function dbconnect()
{
	// Create connection
	$conn=mysqli_connect("localhost","root","","Project");
	// Check connection
	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}
	return $conn;
} 
$conn=dbconnect();
$pwd=str_rot13($_POST['pwd1']);
$sql="UPDATE user_details SET pwd='$pwd' WHERE username='$_SESSION[username]'";
$r=mysqli_query($conn,$sql);
if($r===TRUE)
{
	echo "<script>alert('Password Changed successfully. Please log in again.'); window.open('Logout.php','_self');</script>";
}
$conn->close();
?>