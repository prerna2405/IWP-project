<?php
$flag=0;
$username=$_POST["username"];
$password=str_rot13($_POST["pwd"]);
$s=mysqli_connect("localhost","root","","project");
$a="select * from user_details;";
$r=mysqli_query($s,$a); 
while($m=mysqli_fetch_array($r))
{
	if($username===$m['Username'] && $password===$m['pwd'])
	{
		session_start();
		$flag=1;
		$_SESSION['name']=$m['Name'];
		$_SESSION['username']=$username;
		header('Location:BR.php');
    	break;
	}
}
if($flag==0)
{
	echo "<script>alert('Login unsuccessful. Try again'); window.open('BR_Main.php','_self')</script>";
}
?>